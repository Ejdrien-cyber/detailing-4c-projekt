﻿using System.ComponentModel.DataAnnotations;

namespace DetailingApp.Models;

public class ServiceCategory
{
    [Key]
    public int CategoryID { get; set; }

    [Required, MaxLength(30)]
    public string Code { get; set; } = ""; // EXTERIOR/INTERIOR

    [Required, MaxLength(50)]
    public string Name { get; set; } = "";
}
