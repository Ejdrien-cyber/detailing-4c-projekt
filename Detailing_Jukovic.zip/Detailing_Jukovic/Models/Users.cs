﻿using System.ComponentModel.DataAnnotations;

namespace DetailingApp.Models;

public class User
{
    [Key]
    public int UsersID { get; set; }

    [Required, EmailAddress, MaxLength(100)]
    public string Email { get; set; } = "";

    [Required, MaxLength(255)]
    public string PasswordHash { get; set; } = "";

    [Required, MaxLength(100)]
    public string Name { get; set; } = "";

    [MaxLength(30)]
    public string? Phone { get; set; }
}
