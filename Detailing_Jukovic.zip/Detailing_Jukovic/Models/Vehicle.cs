﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DetailingApp.Models;

public class Vehicle
{
    [Key]
    public int VehicleID { get; set; }

    [ForeignKey(nameof(User))]
    public int User_ID { get; set; }

    [Required, MaxLength(20)]
    public string Licence_Plate { get; set; } = "";

    [Required, MaxLength(50)]
    public string Make { get; set; } = "";

    [Required, MaxLength(50)]
    public string Model { get; set; } = "";

    [MaxLength(30)]
    public string? Color { get; set; }

    public User? User { get; set; }
}
