﻿using Microsoft.EntityFrameworkCore;
using DetailingApp.Models;

namespace DetailingApp.Data;

public class DetailingDbContext : DbContext
{
    public DetailingDbContext(DbContextOptions<DetailingDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();

    // volitelné (pokud jsi přidal modely výše)
    public DbSet<Vehicle> Vehicles => Set<Vehicle>();
    public DbSet<ServiceCategory> ServiceCategories => Set<ServiceCategory>();
    public DbSet<Package> Packages => Set<Package>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        
        modelBuilder.Entity<User>()
            .HasIndex(u => u.Email)
            .IsUnique();

        base.OnModelCreating(modelBuilder);
    }
}
